package com.example.sph_shsm.quickquestions;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private TextView txtQuestion;
    private EditText txtAnswer;
    private Random rnd=new Random();
    int score=0;
    int num1, num2, operation;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        txtQuestion=findViewById(R.id.textQuestion);
        txtAnswer=findViewById(R.id.answerBox);
        GenerateQuestion();
    }

    public void CheckAnswer(View view) {
        String message=txtAnswer.getText().toString();
        int answer;
        try {
            answer = Integer.parseInt(message);
        }catch (Exception e){
            answer=-9999999;

        }
        int finalAnswer=0;
        switch(operation) {
            case 0:
                finalAnswer=num1+num2;
                break;

            case 1:
                finalAnswer=num1-num2;
                break;

            case 2:
                finalAnswer=num1*num2;
                break;

            case 3:
                finalAnswer=num1;
                break;
        }
        if (answer==finalAnswer){
            score++;
            GenerateQuestion();
            txtAnswer.setText("");
        }else{
            Toast.makeText(getApplicationContext(),"Wrong answer! You had a score of "+score, Toast.LENGTH_LONG).show();
            score=0;
            GenerateQuestion();
        }
    }

    public void GenerateQuestion(){
        num1=rnd.nextInt(10)+1;
        num2=rnd.nextInt(10)+1;
        if (num1<num2){ //3, 5
            num1=num1+num2; //8, 5
            num2=num1-num2; //8, 3
            num1=num1-num2; //5, 3
        }
        operation=rnd.nextInt(4);
        if (operation==0){
            txtQuestion.setText(num1+" + "+num2);
        }else if (operation==1){
            txtQuestion.setText(num1+" - "+num2);
        }else if (operation==2){
            txtQuestion.setText(num1+" x "+num2);
        }else{
            int big=num1*num2;
            txtQuestion.setText(big+" / "+num2);
        }
        txtAnswer.setText("");
    }
}
